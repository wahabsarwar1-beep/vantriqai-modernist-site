const db = require('../db');
const { buildTaxInvoice, getSettings } = require('./billing');
const { sendMail, invoiceEmail, mailConfigured } = require('./mailer');
const { renderInvoicePdf, invoiceFilename } = require('./invoicePdf');

/**
 * Sending an invoice to the customer.
 *
 * The CRM raised invoices silently: the monthly run created them and the
 * customer only ever saw one by signing into the portal. The first thing that
 * reached them was a dunning reminder days later saying an invoice was due —
 * a bill they had never been sent.
 *
 * This closes that. The invoice goes out as a PDF ATTACHMENT — a document a
 * customer can file, print and hand to an accountant — with a short covering
 * note in the body saying what it is and when it is due. A bill pasted into
 * an email body is not something anybody can keep.
 *
 * Both are built from the SAME printable document the CRM and the portal
 * render (buildTaxInvoice), so the figures a customer reads in their inbox
 * cannot drift from the figures on the invoice itself.
 *
 * Three rules it will not break:
 *
 *   - An internal invoice is never sent. VantriqAI billing itself is a
 *     transfer; emailing ourselves a bill is noise.
 *   - A send is recorded, so the monthly run cannot email the same invoice
 *     twice, and a human can see what went out and when.
 *   - A failure to send NEVER undoes the invoice. The invoice is the record;
 *     the email is a courtesy. It returns an outcome rather than throwing.
 */

const PORTAL_URL = () => process.env.PORTAL_URL || 'https://portal.vantriqai.com';

/** Has this invoice already been emailed? */
async function alreadySent(invoiceId) {
  const { rows } = await db.query(
    `select 1 from invoice_reminders
      where invoice_id = $1 and action = 'invoice_issued' and outcome = 'sent' limit 1`,
    [invoiceId]
  );
  return !!rows[0];
}

/**
 * Sends one invoice. Returns { outcome, detail } and never throws.
 *
 * outcome is 'sent', 'skipped' or 'failed' — the same vocabulary the dunning
 * log uses, so both appear in one history with one meaning.
 */
async function sendInvoice(invoiceId, { force = false, settings = null } = {}) {
  const record = async (outcome, detail) => {
    await db.query(
      `insert into invoice_reminders (invoice_id, action, outcome, detail)
       values ($1, 'invoice_issued', $2, $3)`,
      [invoiceId, outcome, String(detail || '').slice(0, 300)]
    ).catch(() => {});
    return { outcome, detail };
  };

  try {
    const { rows } = await db.query(
      `select i.*, c.company, c.name, c.email, c.phone, c.is_internal
         from invoices i join clients c on c.id = i.client_id
        where i.id = $1`,
      [invoiceId]
    );
    const inv = rows[0];
    if (!inv) return { outcome: 'skipped', detail: 'Invoice not found.' };

    if (inv.status === 'void') return { outcome: 'skipped', detail: 'Invoice is void.' };

    // The internal account's invoice is a real invoice and is sent like any
    // other — it is the monthly figure the adjustment cheque is written
    // against, so somebody has to receive it. It goes to its own address
    // rather than the client record's, because the "client" here is us.
    const s0 = settings || await getSettings();
    const to = inv.is_internal
      ? (s0.internal_invoice_email || '').trim()
      : inv.email;
    if (!to) {
      return await record('skipped', inv.is_internal
        ? 'No internal invoice address set (Settings → internal invoice email).'
        : 'No email address on the client record.');
    }
    if (!mailConfigured()) {
      return await record('skipped', 'Email is not configured on the server (HOSTINGER_MAIL_TOKEN / HOSTINGER_MAILBOX_ID).');
    }
    if (!force && await alreadySent(invoiceId)) {
      return { outcome: 'skipped', detail: 'Already emailed — pass force to send it again.' };
    }

    const [{ rows: lines }, { rows: pays }, s] = await Promise.all([
      db.query(`select * from invoice_lines where invoice_id = $1 order by position`, [invoiceId]),
      db.query(`select * from payments where invoice_id = $1`, [invoiceId]),
      settings ? Promise.resolve(settings) : getSettings(),
    ]);

    const doc = buildTaxInvoice(inv, inv, s, lines, pays);

    // The attachment is the invoice; the body is a note about it. If the PDF
    // cannot be produced we do NOT quietly fall back to a body-only email —
    // that is how a bill goes out in a form nobody can file, and it already
    // happened once. Fail, log why, and let it be retried.
    const filename = invoiceFilename(doc);
    const pdf = await renderInvoicePdf(doc);

    const { subject, text, html } = invoiceEmail(doc, PORTAL_URL(), { attachmentName: filename });
    await sendMail({
      to, subject, text, html,
      attachments: [{ filename, content: pdf, contentType: 'application/pdf' }],
    });
    return await record('sent', `Emailed ${to} with ${filename} attached.`);
  } catch (err) {
    return await record('failed', err.message || String(err));
  }
}

/** What a send WOULD do, without sending anything. */
async function previewInvoiceSend(invoiceId) {
  const { rows } = await db.query(
    `select i.invoice_number, i.status, c.company, c.email, c.is_internal
       from invoices i join clients c on c.id = i.client_id where i.id = $1`,
    [invoiceId]
  );
  const inv = rows[0];
  if (!inv) return { outcome: 'skipped', detail: 'Invoice not found.' };
  const s = await getSettings();
  const to = inv.is_internal ? (s.internal_invoice_email || '').trim() : inv.email;
  if (!to) {
    return { outcome: 'skipped', ...inv, detail: inv.is_internal
      ? 'No internal invoice address set (Settings → internal invoice email).'
      : 'No email address on the client record.' };
  }
  if (!mailConfigured()) return { outcome: 'skipped', detail: 'Email is not configured on the server.', ...inv };
  if (await alreadySent(invoiceId)) return { outcome: 'skipped', detail: 'Already emailed.', ...inv };
  return { outcome: 'would_send', detail: `Would email ${to}.`, ...inv };
}

/** Everything that has been sent for one invoice, newest first. */
async function deliveryHistory(invoiceId) {
  const { rows } = await db.query(
    `select r.*, s.name as step_name from invoice_reminders r
       left join dunning_steps s on s.id = r.step_id
      where r.invoice_id = $1 order by r.sent_at desc`,
    [invoiceId]
  );
  return rows;
}

module.exports = { sendInvoice, previewInvoiceSend, deliveryHistory, alreadySent };
